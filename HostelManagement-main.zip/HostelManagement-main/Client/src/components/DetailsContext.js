import { createContext } from "react";

export const DetailsContext = createContext(null);